var boxEle = document.body.querySelector(".box");

var userInput = prompt("What is your name?")

var numberOne = 8;
var numberTwo = 2;

boxEle.innerHTML=numberOne+numberTwo;

boxEle.innerHTML=userInput;